# P-Note
P Note 是一款IOS私密记事APP。用户可以自由的建立分类文件夹， 对记事分类管理。P Note 可以设置私密保护开关，为你的记事添加安全保护。P Note 你值得拥有。
![image](https://github.com/fyxjsj/P-Note/raw/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.03.44%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.04.33%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.05.21%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.05.33%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.05.55%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.05.55%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.08.45%20PM.png)
![image](https://github.com/fyxjsj/P-Note/blob/master/screen%20shot/Screen%20Shot%202016-04-13%20at%204.08.53%20PM.png)
