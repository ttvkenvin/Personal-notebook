//
// Created by yaxiongfang on 4/12/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#import "AboutViewController.h"


@implementation AboutViewController {
    __weak IBOutlet UITextView *introTv;

}

- (void)viewDidLoad {
    [super viewDidLoad];

    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 10;// 字体的行间距

    NSDictionary *attributes = @{
            NSFontAttributeName : [UIFont systemFontOfSize:15],
            NSParagraphStyleAttributeName : paragraphStyle,
    };
    
    NSString *Tips = NSLocalizedString(@"P NoteBook is an IOS private note app. Users can freely create classification folders and classify and manage them. P NoteBook You can set a privacy switch to add security to your notes. P NoteBook you deserve it.", nil);
    introTv.attributedText = [[NSAttributedString alloc] initWithString:Tips attributes:attributes];
    introTv.textColor = [UIColor lightGrayColor];
}

@end
