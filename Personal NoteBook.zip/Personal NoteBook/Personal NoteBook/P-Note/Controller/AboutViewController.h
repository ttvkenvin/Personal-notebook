//
// Created by yaxiongfang on 4/12/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseViewController.h"


@interface AboutViewController : BaseViewController
@end