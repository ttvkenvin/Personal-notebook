//
// 主页面
// Created by yaxiongfang on 4/7/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#import "MainViewController.h"
#import "FolderNoteCell.h"
#import "NoteFolderHelper.h"
#import "NoteFolder.h"
#import "FDAlertView.h"
#import "AddFolderView.h"
#import "NotesListViewController.h"
#import "SettingViewController.h"


@implementation MainViewController {

    // 私密开关
    BOOL pSwitch;
    // 保存的密码
    NSString *savePwd;

    NoteFolderHelper *_folderHelper;
    NSMutableArray *folderList;

    // 0 normal 1 edit 2 delete
    int mode;

    UIBarButtonItem *editBarItem;

    UIBarButtonItem *delBarItem;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setTitle:@"P NoteBook"];
    
    editBarItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"edit", @"edit") style:nil target:self action:@selector(editMode)];
    delBarItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"delete", @"delete") style:nil target:self action:@selector(deleteMode)];

    self.navigationItem.leftBarButtonItems = [[NSArray alloc] initWithObjects:editBarItem, delBarItem, nil];


    UIButton *btn2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [btn2 setImage:[UIImage imageNamed:@"setting.png"] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(navigationRightBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [super setNavigationRightBtn:[[UIBarButtonItem alloc] initWithCustomView:btn2]];

    [self initCollection];

    [self initData];

    [self addObserver:NOTIFICATION_UPDATE_FOLDER selector:@selector(selectAllFolders)];
    [self addObserver:NOTIFICATION_UPDATE_SETTING selector:@selector(updateSettingConfig)];
}

- (void)dealloc {
    [self removeObserver];
}

/**
 * 初始化collectionview
 */
- (void)initCollection {

    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];

    flowLayout.minimumInteritemSpacing = 1;//内部cell之间距离
    flowLayout.minimumLineSpacing = 5;//行间距

    flowLayout.itemSize = CGSizeMake((SCREEN_WIDTH - 3) / 4, 110);


    self.collectionView = [[UICollectionView alloc]                   initWithFrame:
            CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 64) collectionViewLayout:flowLayout];

    [self.collectionView setBackgroundColor:[UIColor whiteColor]];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;

    UINib *nib = [UINib nibWithNibName:@"FolderNoteCell" bundle:[NSBundle mainBundle]];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:@"cell"];

    [self.view addSubview:self.collectionView];
}

/**
 * 初始化数据
 */
- (void)initData {
    [self updateSettingConfig];

    folderList = [[NSMutableArray alloc] init];
    _folderHelper = [[NoteFolderHelper alloc] init];
    [self selectAllFolders];
}

/**
 * 更新设置配置值
 */
- (void)updateSettingConfig {
    pSwitch = [UserDefaultsUtils getAppInfoForKeyBool:@"p_switch"];
    savePwd = [UserDefaultsUtils getAppInfoForKey:@"pwd"];
}

/**
 * 查询所有分类目录
 */
- (void)selectAllFolders {

    [folderList removeAllObjects];

    [folderList addObjectsFromArray:[_folderHelper selectAllFolders]];
    NoteFolder *defaultFolder = [[NoteFolder alloc] init];
    defaultFolder.id = 0;
    defaultFolder.name = NSLocalizedString(@"add", @"Add");
    [folderList addObject:defaultFolder];

    [self.collectionView reloadData];
}

/**
 * 添加和更新目录
 */
- (void)addOrUpdateFolder:(int)id name:(NSString *)name andPrivate:(BOOL)isPrivate {

    // 正常模式
    if (mode == 0) {
        if ([_folderHelper addFolder:name andPrivate:isPrivate]) {
            [Tools showTip:self andMsg:NSLocalizedString(@"Added successfully", @"Added successfully")];

            [self selectAllFolders];

            [self.collectionView reloadData];
        }
        else {
            [Tools showTip:self andMsg:NSLocalizedString(@"Add failed", @"Add failed")];
        }
    }
        // 编辑模式
    else if (mode == 1) {
        if ([_folderHelper updateFolder:id name:name andPrivate:isPrivate]) {
            [Tools showTip:self andMsg:NSLocalizedString(@"Successfully modified", @"Successfully modified")];

            [self selectAllFolders];

            [self.collectionView reloadData];
        }
        else {
            [Tools showTip:self andMsg:NSLocalizedString(@"fail to edit", @"fail to edit")];
        }
    }

}

- (void)navigationRightBtnClick {
    SettingViewController *settingViewController = [[SettingViewController alloc] init];
    [self.navigationController pushViewController:settingViewController animated:true];
}

- (void)editMode {
    if (mode == 0) {
        mode = 1;
        editBarItem.title = NSLocalizedString(@"carry out", @"carry out");
        delBarItem.enabled = NO;
    }
    else {
        mode = 0;
        editBarItem.title = NSLocalizedString(@"edit", @"edit");
        delBarItem.enabled = YES;
    }
    [self.collectionView reloadData];
}

- (void)deleteMode {
    if (mode == 0) {
        mode = 2;
        delBarItem.title = NSLocalizedString(@"carry out", @"carry out");
        editBarItem.enabled = NO;
    }
    else {
        mode = 0;
        delBarItem.title = NSLocalizedString(@"delete", @"delete");
        editBarItem.enabled = YES;
    }
    [self.collectionView reloadData];
}

/**
 * section
 */
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

/**
 * 返回单元格数
 */
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return folderList.count;
}

/**
 * 返回一个 单元格布局
 */
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FolderNoteCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    NoteFolder *folder = [folderList objectAtIndex:indexPath.row];
    if (folder.id != 0) {
        cell.imgFolder.image = [UIImage imageNamed:[NSString stringWithFormat:@"folder%d.png", (arc4random() % 11) + 1]];

        // 正常模式下
        if (mode == 0) {
            if (folder.isPrivate) {
                cell.ivPrivate.image = [UIImage imageNamed:@"private.png"];
                cell.ivPrivate.hidden = NO;
            }
            else {
                cell.ivPrivate.hidden = YES;
            }
        }
            // 编辑模式
        else if (mode == 1) {
            cell.ivPrivate.hidden = NO;
            cell.ivPrivate.image = [UIImage imageNamed:@"edit.png"];
        }
            // 删除模式
        else if (mode == 2) {
            cell.ivPrivate.hidden = NO;
            cell.ivPrivate.image = [UIImage imageNamed:@"delete.png"];
        }
    }
    else {
        cell.imgFolder.image = [UIImage imageNamed:@"add.png"];
        cell.ivPrivate.hidden = YES;
    }
    [cell setName:folder.name];
    return cell;
}

/**
 * 单击单元格
 */
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NoteFolder *folder = [folderList objectAtIndex:indexPath.row];

    // 正常模式
    if (mode == 0) {
        // 添加
        if (folder.id == 0) {
            [self showAddOrUpdateDialog:nil];
        }
        else {
            // 私密开关开启 并且 设置过密码
            if (pSwitch && ![StringUtils isEmpty:savePwd] && folder.isPrivate) {
                [self openPwdInputDialog:nil andOnClicked:nil andCompletion:^(NSString *pwd) {
                    if ([pwd isEqualToString:savePwd]) {
                        [self jumpNoteList:folder];
                    }
                    else {
                        [Tools showTip:self andMsg:NSLocalizedString(@"Incorrect password", @"Incorrect password")];
                    }
                }];
            }
            else {
                [self jumpNoteList:folder];
            }
        }
    }
        // 编辑模式
    else if (mode == 1) {
        if (folder.id == 0) {
            return;
        }
        // 私密开关开启 并且 设置过密码
        if (pSwitch && ![StringUtils isEmpty:savePwd]) {
            [self openPwdInputDialog:nil andOnClicked:nil andCompletion:^(NSString *pwd) {
                if ([pwd isEqualToString:savePwd]) {
                    [self showAddOrUpdateDialog:folder];
                }
                else {
                    [Tools showTip:self andMsg:NSLocalizedString(@"Incorrect password", @"Incorrect password")];
                }
            }];
        }
        else {
            [self showAddOrUpdateDialog:folder];
        }
    }
        // 删除模式
    else if (mode == 2) {
        if (folder.id == 0) {
            return;
        }
        NSString *tips =  NSLocalizedString(@"Deleting a category will also delete all the notes in that category, be sure to delete it?", @"Deleting a category will also delete all the notes in that category, be sure to delete it?");
        [super openAlertDialog:tips onClick:^(void) {
            // 私密开关开启 并且 设置过密码
            if (pSwitch && ![StringUtils isEmpty:savePwd]) {
                [self openPwdInputDialog:nil andOnClicked:nil andCompletion:^(NSString *pwd) {
                    if ([pwd isEqualToString:savePwd]) {
                        [self deleteFolder:folder];
                    }
                    else {
                        [Tools showTip:self andMsg:NSLocalizedString(@"Incorrect password", @"Incorrect password")];
                    }
                }];
            }
            else {
                [self deleteFolder:folder];
            }
        }];
    }
}

/**
 * 跳转到note 列表
 */
- (void)jumpNoteList:(NoteFolder *)folder {
    NotesListViewController *notesListViewController = [[NotesListViewController alloc]
            init:folder.id andName:folder.name];
    [self.navigationController pushViewController:notesListViewController animated:true];
}

/**
 * 弹出添加目录对话框
 */
- (void)showAddOrUpdateDialog:(NoteFolder *)folder {
    FDAlertView *alert = [[FDAlertView alloc] init];
    AddFolderView *contentView = [[NSBundle mainBundle] loadNibNamed:@"AddFolderView" owner:nil options:nil].lastObject;
    [contentView init:self andFrame:CGRectMake(0, 0, 270, 215) folder:folder];
    alert.contentView = contentView;
    [alert show];
}

/**
 * 删除目录
 */
- (void)deleteFolder:(NoteFolder *)folder {
    @try {
        [_folderHelper deleteFolder:folder.id];
        [Tools showTip:self andMsg:NSLocalizedString(@"successfully deleted", @"successfully deleted")];
        [folderList removeObject:folder];
        [self.collectionView reloadData];
    }
    @catch (NSException *exception) {
        [Tools showTip:self andMsg:NSLocalizedString(@"failed to delete", @"failed to delete")];
        NSLog(@"Exception occurred: %@, %@", exception, [exception userInfo]);
    }
}

@end

