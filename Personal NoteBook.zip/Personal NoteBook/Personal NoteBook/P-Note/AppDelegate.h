//
//  AppDelegate.h
//  P-Note
//
//  Created by yaxiongfang on 4/7/16.
//  Copyright (c) 2016 yxfang. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end
