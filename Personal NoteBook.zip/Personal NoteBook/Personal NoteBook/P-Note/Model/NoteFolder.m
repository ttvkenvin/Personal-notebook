//
// note 分类model
// Created by yaxiongfang on 4/7/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#import "NoteFolder.h"


@implementation NoteFolder {

}
@end