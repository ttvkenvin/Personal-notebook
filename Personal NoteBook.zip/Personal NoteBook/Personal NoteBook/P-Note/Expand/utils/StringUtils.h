// 字符串处理
// Created by yaxiongfang on 4/9/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface StringUtils : NSObject
/**
 * 判断字符串是否为空
 */
+ (BOOL)isEmpty:(NSString *)text;
@end