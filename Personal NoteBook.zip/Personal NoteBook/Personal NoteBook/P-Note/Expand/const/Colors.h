//
// Created by yaxiongfang on 4/7/16.
// Copyright (c) 2016 yxfang. All rights reserved.
//

#define APP_COLOR [UIColor colorWithRed:3.0/255 green:65.0/255 blue:190.0/255 alpha:1.00]

#define TIP_BG_COLOR [UIColor colorWithRed:0.000 green:0.000 blue:0.000 alpha:0.9]
