//
//  main.m
//  P-Note
//
//  Created by yaxiongfang on 4/7/16.
//  Copyright (c) 2016 yxfang. All rights reserved.
//


#import "AppDelegate.h"


int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }

}
